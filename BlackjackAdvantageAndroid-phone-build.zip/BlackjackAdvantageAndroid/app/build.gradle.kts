plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shinu.blackjackadvantage"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shinu.blackjackadvantage"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-test"
    }
}
