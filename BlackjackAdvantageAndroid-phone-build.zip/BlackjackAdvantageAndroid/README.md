# Blackjack Advantage — Android test project

This is an Android project wrapping the Blackjack Advantage prototype in an offline Android WebView.

## Easiest build without a computer (GitHub Actions)
1. On your phone, open https://github.com and create a free account or sign in.
2. Create a new **public** repository named `BlackjackAdvantage` (public makes the Actions setup simpler; do not upload personal files).
3. Extract this ZIP on your phone. Open the `BlackjackAdvantageAndroid` folder.
4. In the GitHub repository, use **Add file → Upload files**. Upload the contents of this folder, including the hidden `.github/workflows/build-debug-apk.yml` file. If your phone's file picker hides dot-folders, use GitHub's **Add file → Create new file** and create `.github/workflows/build-debug-apk.yml`, then paste the workflow contents from the project. (The workflow file is included.)
5. Commit the files to the `main` branch. GitHub Actions will start building automatically.
6. Open the repository's **Actions** tab, select **Build Blackjack Advantage test APK**, and open the completed run.
7. Under **Artifacts**, download `blackjack-advantage-debug-apk`. Extract the downloaded artifact ZIP; inside is `app-debug.apk`.
8. Tap `app-debug.apk` on your phone and follow Android's install prompts. Only install APKs you built from this project in your own repository.

If GitHub asks you to enable Actions, enable them for the repository. You can also run the workflow manually from the Actions tab using **Run workflow**.

## Build with Android Studio
1. Open the `BlackjackAdvantageAndroid` folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## App details
- App name: Blackjack Advantage
- Package: `com.shinu.blackjackadvantage`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- Version: 1.0-test
- No Internet permission; the bundled prototype runs offline.

## Prototype limitations
The bundled HTML is a development prototype. Its strategy and count-deviation logic is incomplete and not fully validated; do not treat it as casino-grade advice. The betting ramp is illustrative, not a guarantee of profit. Counter state currently resets if the page is recreated or reloaded.
